const express = require("express");
const bodyparser = require('body-parser');
const cors = require('cors');
const mysql = require('mysql2');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyparser.json());

//Database Connection
const db = mysql.createConnection({
	host: '127.0.0.1',
	user: 'root',
	password: '',
	database:'jeu_memoire_db',
	port: 3306
});

//Check Database Connection
db.connect(err=>{
	if(err){
		console.log(err, 'db err');
	}
	else { console.log('Database connected...'); }
});

app.get("/", (req, res) => {
  res.json({ message: "ok" });
});



//////////// HANDLE partie DATA /////////////////////////////
// Get all data
app.get('/partie',(req, res)=>{
	let qr = `select * from historique_des_parties`;
	db.query(qr, (err, result)=>{
		if(err){
			console.log(err, 'errs');
		}
		if(result.length>0){
			res.send({
				message: 'all partie data',
				data: result
			});
		}
	});
});

// Get single data
app.get('/partie/:etatPartie', (req, res)=>{
	let gEtatPartie = req.params.etatPartie;
	let qr= `select * from historique_des_parties where etat_de_la_partie=${gEtatPartie}`;
	db.query(qr, (err, result)=>{
		if(err){console.log(err);}
		if(result.length>0){
			res.send({
				message: 'Single partie data',
				data: result
			});
		}
		else {
			res.send({ message: 'data not found' });
		}
	})
});

// Create data
app.post('/partie', (req, res)=>{
	console.log(req.body, 'createdata');
	let etatCartes = req.body.etatCartes;
	let cartesRetournees= req.body.cartesRetournees;
	let etatDeLaPartie = req.body.etatDeLaPartie;
	
	let qr = `insert into historique_des_parties(etats_des_cartes, cartes_retournees, etat_de_la_partie) values ('${etatCartes}', '${cartesRetournees}', '${etatDeLaPartie}')`;
	
	db.query(qr, (err, result)=> {
		if(err){ console.log(err); }
		
		console.log(result, 'result');
		res.send({ message: 'data inserted',});
	})
});

//Update sing data
app.put('/partie/:id', (req, res)=>{
	let qID = req.params.id;
	
	console.log(req.body, 'update data');
	
	let qr =`update historique_des_parties set etat_de_la_partie =1 WHERE id_historique=${qID}`;
	
	db.query(qr, (err, result)=> {
		if(err){ console.log(err); }
		
		console.log(result, 'result');
		res.send({ message: 'data updated',});
	})
});

//Delete sing data
app.get('/partie/:id', (req, res)=>{
	let qID = req.params.id;
	
	console.log(req.body, 'delete data');
	let qr =`delete from historique_des_parties WHERE id_historique=${qID}`;
	
	db.query(qr, (err, result)=> {
		if(err){ console.log(err); }
		
		console.log(result, 'result');
		res.send({ message: 'data deleted'});
	})
});

/////// END HANDLING USER DATA /////////////////

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});